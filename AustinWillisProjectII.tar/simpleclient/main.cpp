#include <iostream>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <unistd.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <netdb.h>

using namespace std;

int main(int argc, char *argv[])
{
    if (argc < 2) {
        cout << "Usage: simpleclient hostname port";
        return(-1);
    }

    int SocketD = socket(AF_INET,SOCK_STREAM,IPPROTO_TCP);
    struct hostent *host;
    host = gethostbyname(argv[1]);
    sockaddr_in SockAddr;
    SockAddr.sin_port=htons(atoi(argv[2]));
    SockAddr.sin_family=AF_INET;
    SockAddr.sin_addr.s_addr = *((unsigned long*)host->h_addr);

    if (!connect(SocketD, (sockaddr*)&SockAddr, sizeof(SockAddr))) {
    while(1)
    {
        //char rebuffer[80];
        string input;
        char buffer[10000];
        recv(SocketD,buffer,10000,0);
        cout << buffer << endl;
        //cout << string(rebuffer);
        cin >> input;
        strcpy(buffer, input.c_str());
        send(SocketD, buffer, 80, 0);
        recv(SocketD, &rebuffer, 200, 0);
        //string arr = string (buffer);
        cout << string(rebuffer) << endl;
        //if (input == "quit") {
        //   break;
        //}
     }
    } else {
        cout << "Could not connect to server. Try again later." << endl;
    }
    close(SocketD);
}
